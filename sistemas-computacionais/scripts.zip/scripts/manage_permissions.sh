#!/bin/bash

# Script para criar grupos e definir permissões em diretórios de projetos
if [ $# -lt 2 ]; then
    echo "Erro: São necessários pelo menos 2 argumentos"
    echo "Uso: $0 <PROJETO> <USUARIO1> [USUARIO2] [USUARIO3] ..."
    exit 1
fi

#no MAC precisa de um PrimaryGroupID. Utilizei os últimos 5 dígitos do timestamp.
GID=$(date +%s | tail -c 5) 
echo $GID

#Definindo as variáveis
PROJETO=$1
echo "projeto: $PROJETO"
shift

USUARIOS=$@
echo "usuarios: $USUARIOS"

# Verificando se o grupo já existe
sudo dscl . -create /Groups/$PROJETO PrimaryGroupID $GID
sudo dscl . -read /Groups/$PROJETO

cd shared

mkdir $PROJETO

#Criando um usuário se não existir
for usuario in $USUARIOS; do
  if ! dscl . -read /Users/$usuario &>/dev/null; then
    sudo sysadminctl -addUser $usuario -password aula123
    echo "✓ Usuário '$usuario' criado"
  fi
  
  # Adicionar ao grupo
  sudo dscl . -append /Groups/$PROJETO GroupMembership $usuario
  echo "✓ '$usuario' adicionado ao grupo"
done
#Confere se o comando anterior foi executado corretamente
dscl . -read /Groups/$PROJETO GroupMembership

# Definindo as permissões no diretório do projeto
sudo chown -R :$PROJETO ./$PROJETO
sudo chmod -R 770 ./$PROJETO
sudo chmod g+s ./$PROJETO #herdam o grupo do diretório pai

echo "Permissões definidas para o diretório $PROJETO"
ls -ld ./$PROJETO 

# Fim do script